package com.lille1.tps.car.config;

public enum Mode {
	PASSIVE, ACTIVE, EXTENDED_PASSIVE;

}
