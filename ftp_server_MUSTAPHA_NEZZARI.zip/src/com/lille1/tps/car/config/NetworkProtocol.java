package com.lille1.tps.car.config;

public enum NetworkProtocol {
	IPV4, IPV6
}
