java -jar ftp_server.jar
